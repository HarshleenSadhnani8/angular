package com.app.util;

import java.util.Scanner;
import java.io.*;

public class Main {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();
		System.out.println(generate(input));
	}

	public static String generate(String s) {
		StringBuilder builder = new StringBuilder();
		String output = " ";

		if (s.length() >= 5) {
			for (int i = 0; i < s.length(); i += 2) {
				builder.append(s.charAt(i));
			}
			output = builder.toString().toUpperCase();
		} else {
			output = "Invalid input";
		}
		return output;
	}
}
